/********************************************************************************
** Form generated from reading ui file 'WebView.jui'
**
** Created: Sun Feb 21 16:47:09 2010
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

package views;

import com.trolltech.qt.core.*;
import com.trolltech.qt.gui.*;

import com.trolltech.qt.webkit.*;

public class Ui_WebView implements com.trolltech.qt.QUiForm<QMainWindow>
{
    public QAction actionReload;
    public QAction actionStop;
    public QWidget centralwidget;
    public QLineEdit urlEdit;
    public QWebView browser;
    public QMenuBar menubar;
    public QStatusBar statusbar;
    public QToolBar toolBar;

    public Ui_WebView() { super(); }

    public void setupUi(QMainWindow WebView)
    {
        WebView.setObjectName("WebView");
        WebView.resize(new QSize(800, 600).expandedTo(WebView.minimumSizeHint()));
        actionReload = new QAction(WebView);
        actionReload.setObjectName("actionReload");
        actionStop = new QAction(WebView);
        actionStop.setObjectName("actionStop");
        centralwidget = new QWidget(WebView);
        centralwidget.setObjectName("centralwidget");
        urlEdit = new QLineEdit(centralwidget);
        urlEdit.setObjectName("urlEdit");
        urlEdit.setGeometry(new QRect(250, 10, 113, 22));
        browser = new QWebView(centralwidget);
        browser.setObjectName("browser");
        browser.setGeometry(new QRect(0, 0, 800, 600));
        WebView.setCentralWidget(centralwidget);
        menubar = new QMenuBar(WebView);
        menubar.setObjectName("menubar");
        menubar.setGeometry(new QRect(0, 0, 800, 21));
        WebView.setMenuBar(menubar);
        statusbar = new QStatusBar(WebView);
        statusbar.setObjectName("statusbar");
        WebView.setStatusBar(statusbar);
        toolBar = new QToolBar(WebView);
        toolBar.setObjectName("toolBar");
        WebView.addToolBar(com.trolltech.qt.core.Qt.ToolBarArea.TopToolBarArea, toolBar);

        toolBar.addAction(actionReload);
        toolBar.addAction(actionStop);
        retranslateUi(WebView);

        WebView.connectSlotsByName();
    } // setupUi

    void retranslateUi(QMainWindow WebView)
    {
        WebView.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("WebView", "MainWindow", null));
        actionReload.setText(com.trolltech.qt.core.QCoreApplication.translate("WebView", "Reload", null));
        actionStop.setText(com.trolltech.qt.core.QCoreApplication.translate("WebView", "Stop", null));
        toolBar.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("WebView", "toolBar", null));
    } // retranslateUi

}

