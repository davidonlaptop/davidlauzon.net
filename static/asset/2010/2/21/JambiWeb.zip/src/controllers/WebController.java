package controllers;

import views.Ui_WebView;
import views.WebView;

import com.trolltech.qt.core.QUrl;
import com.trolltech.qt.gui.QApplication;

public class WebController {
	/********************************************************************************
	 * Properties / Getters & Setters
	 ********************************************************************************/
	private WebView webView;
	
	private Ui_WebView ui() { return webView.ui(); }

	
	/********************************************************************************
	 * Methods
	 ********************************************************************************/
	public static void main(String[] args) {
		new WebController(args);
    }
	
	public WebController(String[] args) {
		QApplication.initialize(args);

        webView = new WebView(null);
        webView.show();
        
        initEvents();
        
        ui().urlEdit.setText( "http://comics.com/peanuts/" );
        openURL();
        
        QApplication.exec();
	}
	
	private void initEvents() {
		ui().actionReload.triggered.connect(this, "onReloadClicked()");
		ui().actionStop.triggered.connect(this, "onStopClicked()");
		
        ui().urlEdit.returnPressed.connect(this, "onUrlEditReturnPressed()");

        ui().browser.loadStarted.connect(this, "onLoadStarted()");
        ui().browser.loadProgress.connect(this, "onLoadProgress(int)");
        ui().browser.loadFinished.connect(this, "onLoadDone()");
        ui().browser.urlChanged.connect(this, "onUrlChanged(QUrl)");
        
        webView.closed.connect(this, "onClosed()");
    }
	
	private void openURL() {
		String text = ui().urlEdit.text();

        if (text.indexOf("://") < 0)
            text = "http://" + text;

        ui().browser.load(new QUrl(text));
	}

	
	
	/********************************************************************************
	 * Signals and Slots (Events)
	 ********************************************************************************/
	private void onReloadClicked() {
		ui().browser.reload();
	}
	
	private void onStopClicked() {
		ui().browser.stop();
	}

    private void onUrlEditReturnPressed() {
        openURL();
    }

    private void onUrlChanged(QUrl url) {
        ui().urlEdit.setText(url.toString());
    }

    private void onLoadStarted() {
        ui().statusbar.showMessage("Starting to load: " + ui().urlEdit.text());
    }

    private void onLoadDone() {
    	ui().statusbar.showMessage("Loading done...");
    }

    private void onLoadProgress(int x) {
    	ui().statusbar.showMessage("Loading: " + x + " %");
    }
    
    private void onClosed() {
    	ui().browser.loadProgress.disconnect(this);
        ui().browser.loadFinished.disconnect(this);
    }
}
