package views;

import com.trolltech.qt.gui.*;

public class WebView extends QMainWindow {
	/********************************************************************************
	 * Properties / Getters & Setters
	 ********************************************************************************/
    private Ui_WebView ui = new Ui_WebView();
    
    public Ui_WebView ui() { return this.ui; }
    
    public Signal0 closed = new Signal0(); 
    

	/********************************************************************************
	 * Methods
	 ********************************************************************************/
    public WebView(QWidget parent) {
        super(parent);
        ui.setupUi(this);
        
        ui.toolBar.addWidget( ui.urlEdit );
        ui.toolBar.setFloatable(false);
        ui.toolBar.setMovable(false);
        
        ui.actionReload.setIcon(new QIcon("classpath:/refresh32.png"));
        ui.actionStop.setIcon(new QIcon("classpath:/stop32.png"));
        
        setWindowTitle("A custom browser for your application");
    }
    

	/********************************************************************************
	 * Signal and Slots (Events)
	 ********************************************************************************/
	@Override
    protected void closeEvent(QCloseEvent event) {
		this.closed.emit();
    }
}
